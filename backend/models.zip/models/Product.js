
const mongoose = require("mongoose");

// Reusable image structure
const productImageSchema = new mongoose.Schema(
  {
    url: {
      type: String,
      required: true,
      trim: true,
    },
    slot: {
      type: String,
      enum: ["main", "ports", "packaging", "scale", "extra"],
      default: "extra",
    },
    variantValue: {
      type: String,
      trim: true,
      default: null,
    },
  },
  { _id: false }
);

// Product variant structure
const variantSchema = new mongoose.Schema(
  {
    sku: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },
    attributes: {
      type: mongoose.Schema.Types.Mixed,
      default: {},
    },
    regularPrice: {
      type: Number,
      required: true,
      min: 0.01,
    },
    salePrice: {
      type: Number,
      min: 0,
      default: null,
    },
    stockQuantity: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },
    lowStockThreshold: {
      type: Number,
      min: 1,
      default: 3,
    },
    maxOrderQuantity: {
      type: Number,
      min: 1,
      default: null,
    },
    isDefault: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: false }
);

variantSchema.pre("validate", function () {
  if (
    this.salePrice !== null &&
    this.salePrice !== undefined &&
    this.salePrice >= this.regularPrice
  ) {
    this.invalidate(
      "salePrice",
      "Sale price must be lower than regular price."
    );
  }
});

// Product specification structure
const specificationSchema = new mongoose.Schema(
  {
    group: {
      type: String,
      required: true,
      trim: true,
    },
    key: {
      type: String,
      required: true,
      trim: true,
    },
    label: {
      type: String,
      required: true,
      trim: true,
    },
    value: {
      type: mongoose.Schema.Types.Mixed,
      required: true,
    },
  },
  { _id: false }
);

const boxContentSchema = new mongoose.Schema(
  {
    qty: {
      type: Number,
      required: true,
      min: 1,
    },
    item: {
      type: String,
      required: true,
      trim: true,
    },
  },
  { _id: false }
);

const variantOptionSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    values: {
      type: [String],
      validate: {
        validator: (values) => values.length > 0,
        message: "Each variant option must have at least one value.",
      },
    },
  },
  { _id: false }
);

const productSchema = new mongoose.Schema(
  {
    // Product identity
    title: {
      type: String,
      trim: true,
      minlength: 10,
      maxlength: 120,
    },
    slug: {
      type: String,
      lowercase: true,
      trim: true,
      unique: true,
      sparse: true,
    },
    brandId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Brand",
      default: null,
    },
    mpn: {
      type: String,
      trim: true,
      uppercase: true,
      default: "",
    },
    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Category",
      default: null,
    },
    tags: {
      type: [
        {
          type: String,
          trim: true,
          maxlength: 25,
        },
      ],
      default: [],
      validate: {
        validator: (tags) => tags.length <= 8,
        message: "A product can have a maximum of 8 tags.",
      },
    },

    // Authenticity and condition
    condition: {
      type: String,
      enum: [
        "new_sealed",
        "open_box",
        "manufacturer_refurbished",
        "seller_refurbished",
        "used_grade_a",
        "used_grade_b",
      ],
      default: "new_sealed",
    },
    conditionNotes: {
      type: String,
      trim: true,
      default: "",
    },
    regionVariant: {
      type: String,
      enum: [
        "Official Local Variant (BD)",
        "Global / International",
        "US Variant",
        "UK / EU Variant",
        "CN (China ROM)",
        "Japan Variant",
      ],
      default: "Official Local Variant (BD)",
    },
    gtin: {
      type: String,
      trim: true,
      default: "",
      validate: {
        validator: (value) =>
          !value || /^(\\d{8}|\\d{12}|\\d{13}|\\d{14})$/.test(value),
        message: "GTIN must contain 8, 12, 13, or 14 digits.",
      },
    },
    verificationProof: {
      type: String,
      select: false,
      default: "",
    },

    // Product images and video
    images: {
      type: [productImageSchema],
      default: [],
    },
    videoUrl: {
      type: String,
      trim: true,
      default: "",
    },

    // Product description
    highlights: {
      type: [
        {
          type: String,
          trim: true,
          maxlength: 100,
        },
      ],
      default: [],
      validate: {
        validator: (items) => items.length <= 5,
        message: "A maximum of 5 highlights is allowed.",
      },
    },
    description: {
      type: String,
      default: "",
      trim: true,
    },
    boxContents: {
      type: [boxContentSchema],
      default: [],
    },
    plugType: {
      type: String,
      enum: [
        "US 2-Pin (Type A/B)",
        "UK 3-Pin (Type G)",
        "EU 2-Pin (Type C/F)",
        "Universal / USB-Powered",
        "",
      ],
      default: "",
    },
    includesAdapter: {
      type: Boolean,
      default: false,
    },

    // Variants and inventory
    hasVariants: {
      type: Boolean,
      default: false,
    },
    variantOptions: {
      type: [variantOptionSchema],
      default: [],
      validate: {
        validator: (items) => items.length <= 2,
        message: "A maximum of 2 variant axes is allowed.",
      },
    },
    variants: {
      type: [variantSchema],
      default: [],
    },

    // Warranty and returns
    warrantyType: {
      type: String,
      enum: [
        "Official Brand Warranty",
        "Seller / Shop Service Warranty",
        "Instant Replacement Only",
        "International Warranty",
        "No Warranty",
      ],
      default: "No Warranty",
    },
    warrantyDuration: {
      value: {
        type: Number,
        min: 1,
        default: null,
      },
      unit: {
        type: String,
        enum: ["Days", "Months", "Years", "Lifetime"],
        default: "Months",
      },
    },
    warrantyPolicy: {
      type: String,
      trim: true,
      maxlength: 300,
      default: "",
    },
    returnPolicy: {
      type: String,
      enum: [
        "7-Day Easy Return (Unopened/Defective)",
        "3-Day DOA (Dead on Arrival) Replacement",
        "Non-Returnable",
      ],
      default: "Non-Returnable",
    },

    // Shipping
    shipping: {
      weightGrams: {
        type: Number,
        min: 0,
        default: null,
      },
      dimensions: {
        lengthCm: { type: Number, min: 0, default: null },
        widthCm: { type: Number, min: 0, default: null },
        heightCm: { type: Number, min: 0, default: null },
      },
    },
    dispatchTime: {
      type: String,
      enum: [
        "Same-Day Dispatch (Orders before 3 PM)",
        "1–2 Business Days",
        "3–5 Business Days",
        "Pre-Order",
      ],
      default: "1–2 Business Days",
    },
    preorderReleaseDate: {
      type: Date,
      default: null,
    },

    // Technical specifications
    specifications: {
      type: [specificationSchema],
      default: [],
    },

    // Seller references
    sellerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    seller: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },

    // Legacy compatibility fields
    // Retained while existing frontend and APIs are upgraded.
    name: {
      type: String,
      trim: true,
      default: "",
    },
    price: {
      type: Number,
      min: 0,
      default: null,
    },
    image: {
      type: String,
      trim: true,
      default: "",
    },
  },
  {
    timestamps: true,
  }
);

// Keep old and new product fields synchronized.
productSchema.pre("validate", function () {
  // Legacy name -> new title
  if (!this.title && this.name) {
    this.title = this.name;
  }

  // New title -> legacy name
  if (!this.name && this.title) {
    this.name = this.title;
  }

  // Generate slug from title and MPN
  if (!this.slug && this.title) {
    const slugBase = `${this.title}-${this.mpn || ""}`;

    this.slug = slugBase
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");
  }

  // Convert an old product image into the new image structure.
  if (this.images.length === 0 && this.image) {
    this.images.push({
      url: this.image,
      slot: "main",
    });
  }

  // Keep the old image field synchronized.
  if (!this.image && this.images.length > 0) {
    this.image = this.images[0].url;
  }

  // Convert old pricing into a default variant.
  if (this.variants.length === 0 && this.price !== null) {
    this.variants.push({
      sku: `LEGACY-${this._id}`,
      attributes: {},
      regularPrice: this.price,
      stockQuantity: 0,
      lowStockThreshold: 3,
      isDefault: true,
    });
  }

  // Keep legacy price synchronized with the default variant.
  if (this.variants.length > 0) {
    const defaultVariant =
      this.variants.find((variant) => variant.isDefault) ||
      this.variants[0];

    if (!defaultVariant.isDefault) {
      defaultVariant.isDefault = true;
    }

    if (this.price === null || this.price === undefined) {
      this.price =
        defaultVariant.salePrice ?? defaultVariant.regularPrice;
    }
  }

  // Preserve the legacy category-independent name.
  if (!this.name && this.title) {
    this.name = this.title;
  }
});

// Product indexes
productSchema.index({ title: "text", tags: "text" });
productSchema.index({ categoryId: 1, createdAt: -1 });
productSchema.index({ brandId: 1 });
productSchema.index({ sellerId: 1 });
productSchema.index({ "variants.sku": 1 });

module.exports =
  mongoose.models.Product ||
  mongoose.model("Product", productSchema);
