const mongoose = require("mongoose");

const specificationTemplateSchema = new mongoose.Schema(
  {
    group: {
      type: String,
      required: true,
      trim: true,
      maxlength: 60,
    },

    key: {
      type: String,
      required: true,
      trim: true,
      maxlength: 60,
    },

    label: {
      type: String,
      required: true,
      trim: true,
      maxlength: 80,
    },

    inputType: {
      type: String,
      enum: ["text", "number", "boolean", "select", "multiselect"],
      default: "text",
    },

    options: {
      type: [String],
      default: [],
    },

    unit: {
      type: String,
      trim: true,
      default: "",
    },

    required: {
      type: Boolean,
      default: false,
    },

    filterable: {
      type: Boolean,
      default: false,
    },

    displayOrder: {
      type: Number,
      default: 0,
    },
  },
  { _id: false }
);

const categorySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 80,
    },

    slug: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },

    description: {
      type: String,
      trim: true,
      maxlength: 500,
      default: "",
    },

    parentCategory: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Category",
      default: null,
    },

    level: {
      type: Number,
      min: 1,
      max: 3,
      default: 1,
    },

    image: {
      type: String,
      trim: true,
      default: "",
    },

    specificationTemplate: {
      type: [specificationTemplateSchema],
      default: [],
    },

    isActive: {
      type: Boolean,
      default: true,
    },

    sortOrder: {
      type: Number,
      default: 0,
    },
  },
  { timestamps: true }
);

// Generate a URL-friendly slug from the category name.
categorySchema.pre("validate", async function () {
  if (!this.slug && this.name) {
    this.slug = this.name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");
  }

  if (!this.parentCategory) {
    this.level = 1;
    return;
  }

  if (this.parentCategory.equals(this._id)) {
    throw new Error("A category cannot be its own parent.");
  }

  const parent = await this.constructor.findById(
    this.parentCategory
  );

  if (!parent) {
    throw new Error("Parent category does not exist.");
  }

  if (parent.level >= 3) {
    throw new Error("Categories cannot exceed three levels.");
  }

  this.level = parent.level + 1;
});

categorySchema.index({ parentCategory: 1, isActive: 1 });
categorySchema.index({ name: 1 });

module.exports =
  mongoose.models.Category ||
  mongoose.model("Category", categorySchema);