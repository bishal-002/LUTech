const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },

    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },

    password: {
      type: String,
      required: true,
    },

    role: {
      type: String,
      enum: ["customer", "seller", "admin"],
      default: "customer",
      required: true,
    },

    sellerStatus: {
      type: String,
      enum: ["not_applicable", "pending", "approved", "rejected"],
      default: "not_applicable",
    },

    otp: {
      type: String,
    },

    otpExpires: {
      type: Date,
    },

    address: {
      type: String,
      default: "",
    },

    isVerified: {
      type: Boolean,
      default: false,
    },

    storeName: {
      type: String,
      trim: true,
      default: "",
    },

    storeDescription: {
      type: String,
      trim: true,
      default: "",
    },

    storePhone: {
      type: String,
      trim: true,
      default: "",
    },

    storeAddress: {
      type: String,
      trim: true,
      default: "",
    },
    sellerApplication: {
      reason: {
        type: String,
        trim: true,
        default: "",
      },

      submittedAt: {
        type: Date,
        default: null,
      },

      reviewedAt: {
        type: Date,
        default: null,
      },

      reviewNote: {
        type: String,
        trim: true,
        default: "",
      },
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("User", userSchema);